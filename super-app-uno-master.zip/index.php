<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
</head> 
<body>

<h1>Icono del día</h1>

<img src="randomicon.php"/>

</body>
</html>



